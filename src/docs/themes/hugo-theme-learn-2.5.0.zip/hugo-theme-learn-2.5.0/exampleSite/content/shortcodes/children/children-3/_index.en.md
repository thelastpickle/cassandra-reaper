+++
title = "page 3"
description = "This is a demo child page"
+++

This is a demo child page, not displayed in the menu